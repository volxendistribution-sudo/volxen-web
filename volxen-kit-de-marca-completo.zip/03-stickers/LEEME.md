# Stickers VOLXEN (36)
- paquetes-whatsapp/: 4 archivos .wastickers para abrir con Sticker Maker (uno por categoría).
- Carpetas 01 a 04: cada sticker en WebP 512 x 512 (listo para WhatsApp) y su copia PNG en la subcarpeta png/.
- icono-bandeja-96.png: icono del paquete.
Tipografía de los stickers: Carlito Bold, provisional (autorizada solo para stickers). Se rehacen con DM Sans cuando esté disponible.
Se retiró el sticker "Factura · Garantía · Propiedad" porque no aplica al negocio.
Usa "Garantía" y "Envío gratis" solo cuando apliquen al producto.
