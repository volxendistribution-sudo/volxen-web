# Cómo trabajar con los iconos de VOLXEN (instrucciones para opencode)

Fuente única de iconos: `volxen-icons.json` (52 iconos). Lógica de asignación: `volxen-iconfor.js`. Referencia visual que debe quedar igual: `spec-badges-demo.html`.

## Reglas obligatorias
1. El icono se incrusta como `<svg viewBox="0 0 24 24">` en línea. No usar `<use>`, ni `sprite.svg`, ni emojis, ni fuentes de iconos, ni imágenes.
2. Estilo del SVG: `fill="none"`, `stroke="currentColor"`, `stroke-width="1.75"`, `stroke-linecap="round"`, `stroke-linejoin="round"`. Si el CSS global rellena (`fill`), anular con `svg *{fill:none}`.
3. Insignia: círculo de 56 px con el icono a 28 px (la mitad). Si hay 1 a 3 especificaciones: 72 px y 36 px.
4. Colores: círculo verde `#2E4A3F` con icono marfil `#F8F7F4`; círculo dorado `#C8A165` con icono carbón `#1E1D1B`. Nunca blanco sobre dorado.
5. El icono lo elige `iconFor(texto)` con la tabla del archivo JS. La IA no inventa ni cambia iconos. Si no hay coincidencia sale `check`. Para un icono nuevo, se añade una línea a la tabla `MAP`.
6. Texto: MAYÚSCULAS, mínimo 20 px por cada 1080 px de ancho del anuncio, número y unidad separados ("600 W", "15 A"). Máximo 5 especificaciones por anuncio.
7. Con 1 a 3 especificaciones, centrar el bloque verticalmente entre el subtítulo y la franja de garantía (evita el hueco vacío del anuncio del TV).
8. Si el proceso que genera la imagen no pinta el SVG (resvg, satori, canvas), sustituir `currentColor` por el color en hexadecimal.

## Pruebas antes de dar el trabajo por terminado
- Abrir `spec-badges-demo.html` en el navegador: los 10 ejemplos muestran su icono completo, nada de puntos ni formas sueltas.
- `iconFor("600 W")` es `potencia`, `iconFor("15 AMP")` es `corriente`, `iconFor("Bifaciales monocristalinos")` es `bifacial`, `iconFor("Gran panel")` es `dimensiones`, `iconFor("Fuego")` es `llama`, `iconFor("LED / LCD")` es `pantalla`.
- Si un icono sale mal, mostrar en consola el nombre que devuelve `iconFor` antes de tocar el diseño.

## Lista de iconos
autonomia, carga-rapida, estacion, potencia, voltaje, garantia, velocidad, alcance, peso, dimensiones, tiempo-carga, panel-solar, puertos, toma-ac, silencioso, control-remoto, iluminacion, eficiencia, climatizacion, nevera, pantalla, cocina, lavadora, entrega, movilidad, resistente-agua, llama, corriente, bifacial, check, wifi, bluetooth, smart-tv, aire, sol, ciclos, bateria-llena, inversor, enchufe, pago, precio, calendario, calidad, telefono, motor, rueda, personas, subida, temperatura, induccion, pulgadas, app-movil
